import { Routes } from '@angular/router';
import { LocationPlanComponent } from 'app/location-plan/location-plan.component';

export const LocationPlanRoutes: Routes = [
  {
    path: '',
    component: LocationPlanComponent
  }
];