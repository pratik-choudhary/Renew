import { Routes } from '@angular/router';
import { SiteTeamComponent } from 'app/site-team/site-team.component';

export const SiteTeamRoutes: Routes = [
  {
    path: '',
    component: SiteTeamComponent
  }
];