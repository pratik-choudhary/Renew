import { Routes } from '@angular/router';

import { ChecklistComponent } from './checklist.component';

export const ChecklistRoutes: Routes = [
  {
    path: '',
    component: ChecklistComponent
  }
];
