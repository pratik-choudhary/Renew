import { Routes } from '@angular/router';
import { ReportComponent } from 'app/reports/reports.component';

export const ReportRoutes: Routes = [
  {
    path: '',
    component: ReportComponent
  }
];